entero = 5
decimal = 1.2
suma = entero+decimal
print(suma)
print (25/4)
print (25//4)
print (25**3)
